# homework following intro to python session 1 (8/23/17)

# 1:

# write a function called 'tip_calculator' that accepts
# three arguments (meal_cost, tax_rate, tip_percent)
# and prints out the total cost of a meal including
# tax and tip:


# bonus: what if you wanted to improve the function
# by calculating how much each person in a group owed
# for the meal after adding tax and tip?:



# 2:

# write a function that reverses the input (a list,
# provided below):

# list to reverse:
reverse_input = [6, 4, 'a_string', 3, 'another_string', 1.01, True]




# 3:

# using an imported python module, generate a list of
# 100 random integers between 0 and 1000 and save it to a variable



# 4:

# 4 A: what is the mean of this list?


# 4 B: what is the second highest value in this list?



# 5:

# write a function that counts how many even and
# odd numbers there are in a list; use this function
# to determine the number of evens and odds in the
# randomly generated list you just made in Q.3



# dictionaries

# class_roster is a dictionary containing 8th and 9th grade student
# information, including student IDs (8th grader's start w/ '8',
#  9th grader's start w/ '9') and grades on three exams

class_roster = {'ava': {'student_ID': '9113', 'test_scores': [94, 89, 95]},
 'jessica': {'student_ID': '9588', 'test_scores': [89, 95, 97]},
 'kendrick': {'student_ID': '8724', 'test_scores': [93, 91, 97]},
 'kyle': {'student_ID': '9988', 'test_scores': [85, 94, 92]},
 'morty': {'student_ID': '8776', 'test_scores': [74, 83, 81]},
 'rick': {'student_ID': '8423', 'test_scores': [99, 93, 94]},
 'titus': {'student_ID': '9441', 'test_scores': [88, 84, 85]},
 'veronica': {'student_ID': '8724', 'test_scores': [97, 95, 95]}}

# 6. A:

# update the class roster (programmatically) with the following students:


students_to_add = [['laura', 9111, [96, 93, 97]], ['stephanie', 9622, [93, 94, 97]], ['jared', 8954, [95, 91, 95]]]


# 6. B:

# create a list of all 8th grade student names:


# 6. C:

# add a new key/value pair for each student that represents their
# final grade (average of their 3 exam scores)


# 6. D:

# what is the class average for 8th graders? 9th graders?

